#keeps all external functions for view.py
import matplotlib.pyplot as plt
import seaborn as sns
import numpy as np
from io import BytesIO #simple stream of membytes that behaves like files, used to use and send to internet
import base64
from .alonbackend import get_yearrangecounts, gpd, wkt

def get_image():
# create a graph, put it in temp memory, pass it to get_performance_plot
# which would bring it to views, and pass it to main.html

    # create a bytesbuffer for image to save
    buffer = BytesIO()
    # create plot with the use of bytesio obj as its 'file' - filelike
    plt.savefig(buffer, format='png')
    # set cursor to the beginning of stream
    buffer.seek(0)
    # retrieve the entire content of the file
    image_png = buffer.getvalue()

    # takes binchunks and encodes it into chracters [A-Za-z0-9+=]
    graph = base64.b64encode(image_png)
    graph = graph.decode('utf-8')

    # free buffer memory
    buffer.close()
    return graph

# for reference: https://matplotlib.org/3.2.1/tutorials/introductory/usage.html#what-is-a-backend
#matplotlib as backend
#AGG to use png files for web app
# def absolute_value(val):
#     a  = np.round(val/100.*sum(x), 0)
#     return a

def get_performance_plot(chart_type,*args, **kwargs):
    plt.switch_backend('AGG')
    fig = plt.figure(figsize=(5,5))
    #kwargs from views, get to extract speciic
    x = kwargs.get('x')
    y = kwargs.get('y')
    data = kwargs.get('data')
    gdf = kwargs.get('gdf')
    title = kwargs.get('title')
    xlabel = kwargs.get('xlabel')
    print(title)
    if chart_type == "bar plot":
        plt.xlabel(xlabel)
        plt.ylabel("Frequency")
        plt.title(title)
        plt.bar(x,y)
    elif chart_type == "line plot":
        plt.xlabel("Time")
        plt.ylabel("Frequency")
        plt.title(title)
        plt.plot(x,y)
    elif chart_type == "pie chart":
        my_explode = tuple([0.05]*len(x))
        plt.pie(y, labels = x, explode =my_explode)
    elif chart_type == "heat map":
        fig = plt.figure(figsize=(7,7))
        plt.pcolor(data)
        plt.yticks(np.arange(0.5, len(data.index), 1), [x for x in range(1,11)])
        plt.xticks(np.arange(0.5, len(data.columns), 1), data.columns)
        plt.xlabel("Year")
        plt.ylabel("Buoy number")
        plt.title(title)
        plt.colorbar()
    elif chart_type == "geoplot":
        fig = plt.figure(figsize=(15,15))
        datagdf = gpd.GeoDataFrame(data, geometry='Coordinates')
        ax = gdf.plot(figsize=(15,15))
        datagdf.plot(ax=ax, color='red')

    # automatically adjust fit of graph to the area
    plt.tight_layout()
    print(type(fig))
    graph = get_image()
    print(type(graph))
    return graph
