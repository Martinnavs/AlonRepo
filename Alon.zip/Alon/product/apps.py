from django.apps import AppConfig

#application configuration
class ProductConfig(AppConfig):
    name = 'product'
