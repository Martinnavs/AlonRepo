from django.contrib import admin
from .models import BarangayBuoy # step 2
from .models import Intruder, Fisherman, BuoyMessage # step 2

# Register your models here.
admin.site.register(BarangayBuoy) # step 2
admin.site.register(Intruder) # step 2
admin.site.register(BuoyMessage)
admin.site.register(Fisherman)
