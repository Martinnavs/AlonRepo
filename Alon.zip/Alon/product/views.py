from django.shortcuts import render
import pandas as pd
from .models import BarangayBuoy, Intruder, Fisherman, BuoyMessage
from .utils import get_performance_plot
from django.http import HttpResponseRedirect
from django import template
register = template.Library()
from .alonbackend import *
# Create your views here.

#step 3
@register.simple_tag
def to_list(*args):
    return args

def home_view(request):
    return render(request,'index.html')

def performance_view(request):
    return render(request, 'performance.html')

def statistics_view(request):
    return render(request, 'statistics.html')

def plots_view(request):
    return render(request, 'plots.html')

def chart_select_view(request):
    barangay_df = pd.DataFrame(BarangayBuoy.objects.all().values())
    intruder_df = pd.DataFrame(Intruder.objects.all().values())
    fisherman_df = pd.DataFrame(Fisherman.objects.all().values())
    buoymsg_df = pd.DataFrame(BuoyMessage.objects.all().values())

    holder_df = None
    error_message = None

    #databases, add katong optional dropdown list
    if barangay_df.shape[0] > 0 or intruder_df.shape[0] > 0 or fisherman_df.shape[0] > 0 or buoymsg_df.shape[0] > 0:
        if request.method == 'POST':
            db = request.POST['database']
            level = request.POST['level']
            province = request.POST['province']
            municipality = request.POST['municipality']
            barangay = request.POST['barangay']
            date_from = request.POST['date_from']
            date_to = request.POST['date_to']


            if db != "":
                if db == "buoys":
                    barangay_df = pd.DataFrame(BarangayBuoy.objects.all().values())
                    if barangay_df.shape[0] > 0 :
                        if level != "":
                            if level == "provincial" or level == "municipal" or level == "barangay":
                                if province != "":
                                    if level == "municipal" or level == "barangay":
                                        if municipality != "":
                                            if level == "barangay": # barangay level
                                                barangay_df = barangay_df[((barangay_df['province'] == province) & (barangay_df['municipality'] == municipality)) & (barangay_df['barangay'] == barangay)]
                                                if barangay_df.shape[0] > 0 and not barangay_df.empty:
                                                    holder_df = barangay_df
                                                else:
                                                    error_message = "No records exist"
                                            else: # municipal level
                                                barangay_df = barangay_df[(barangay_df['province'] == province) & (barangay_df['municipality'] == municipality)]
                                                if barangay_df.shape[0] > 0 and not barangay_df.empty:
                                                    holder_df = barangay_df
                                                else:
                                                    error_message = "No records exist"
                                        else:
                                            error_message = "No municipality selected" # null municipality
                                    else: # provincial level
                                        barangay_df = barangay_df[(barangay_df['province'] == province)]
                                        if barangay_df.shape[0] > 0 and not barangay_df.empty:
                                            holder_df = barangay_df
                                        else:
                                            error_message = "No records exist"
                                else:
                                    error_message = "No province selected" # null province
                            else:
                                error_message = "No such choice exists" # choice only
                        else:
                            error_message = "No level selected" # null level
                    else:
                        error_message = "barangay Database Empty"
                else:
                    selection_df = None

                    if db == "fishermen":
                        selection_df = fisherman_df
                    elif db == "intruders":
                        selection_df = intruder_df
                    else:
                        selection_df = buoymsg_df

                    if selection_df.shape[0] > 0 :
                        selection_df['date'] = selection_df['date'].apply(lambda x: x.strftime('%Y-%m-%d'))
                        if level != "":
                            if level == "provincial" or level == "municipal" or level == "barangay":
                                if province != "":
                                    if level == "municipal" or level == "barangay":
                                        if municipality != "":
                                            if level == "barangay": # barangay level
                                                selection_df = selection_df[((selection_df['province'] == province) & (selection_df['municipality'] == municipality)) & (selection_df['barangay'] == barangay)]
                                                if selection_df.shape[0] > 0 and not selection_df.empty:
                                                    holder_df = selection_df[(selection_df['date'] > date_from) & (selection_df['date'] <= date_to)]
                                                else:
                                                    error_message = "No records exist"
                                            else: # municipal level
                                                selection_df = selection_df[(selection_df['province'] == province) & (selection_df['municipality'] == municipality)]
                                                if selection_df.shape[0] > 0 and not selection_df.empty:
                                                    holder_df = selection_df[(selection_df['date'] > date_from) & (selection_df['date'] <= date_to)]
                                                else:
                                                    error_message = "No records exist"

                                        else:
                                            error_message = "No municipality selected" # null municipality
                                    else: # provincial level
                                        selection_df = selection_df[(selection_df['province'] == province)]
                                        if selection_df.shape[0] > 0 and not selection_df.empty:
                                            holder_df = selection_df[(selection_df['date'] > date_from) & (intruder_df['date'] <= date_to)]
                                        else:
                                            error_message = "No records exist"
                                else:
                                    error_message = "No province selected" # null province
                            else:
                                error_message = "No such choice exists" # choice only
                        else:
                            error_message = "No level selected" # null level
                    else:
                        error_message = "Selected Database Empty"
            else:
                error_message = "No database selected"
    else:
        error_message = "No record in the database"

    #what you want to display, used in main html
    if type(holder_df) == pd.DataFrame and not holder_df.empty:
        holder_df = holder_df.to_html()
    else:
        if type(holder_df) == pd.DataFrame:
            error_message = "No records exist"
        holder_df = None

    context = {
        # 'graph' : graph,
        'holder_df' : holder_df,
        'error_message' : error_message,
    }

    return render(request, 'product/performance.html',context)

# ACTUAL REPORTED OR NOT
def stats_view(request):
    barangay_df = pd.DataFrame(BarangayBuoy.objects.all().values())
    intruder_df = pd.DataFrame(Intruder.objects.all().values())
    error_message = None
    graph = None
    holder_df = None
    monthnames = ['','Jan','Feb','Mar','Apr','May','Jun','Jul','Aug','Sep','Oct','Nov','Dec']
    title = ""
    recogtext = " Intruders"
    xlabel = ""

    if intruder_df.shape[0] > 0 and barangay_df.shape[0] > 0:
        if request.method == 'POST':
            province = request.POST['province']
            municipality = request.POST['municipality']
            barangay = request.POST['barangay']
            statistic = request.POST['statistic']
            buoynum = request.POST['buoynum']
            timescale = request.POST['timescale']
            year = request.POST['year']
            month = request.POST['month']
            year_from = request.POST['year_from']
            year_to = request.POST['year_to']
            buoynum = "b"+buoynum

            intruder_df['date'] = intruder_df['date'].apply(lambda x: x.strftime('%Y-%m-%d'))
            intruder_df['Year'] = intruder_df['date'].apply(lambda x: x[0:4]) # CREATING A YEAR COLUMN
            intruder_df['Month'] = intruder_df['date'].apply(lambda x: x[5:7]) # CREATING A MONTH COLUMN

            if province != "" and municipality != "" and barangay != "": # location string check
                intruder_df = intruder_df[((intruder_df['province'] == province) & (intruder_df['municipality'] == municipality)) & (intruder_df['barangay'] == barangay)]
                if intruder_df.empty:
                    error_message = "No records exist"
                else:
                    if (timescale != "" and statistic != "s4" and statistic != "s8") or statistic == "s4" or statistic == "s8":
                        if statistic != "" and int(statistic[1]) > 4:
                            recogtext = " Unrecognized " + recogtext
                            intruder_df = intruder_df[intruder_df['recognized'] == np.bool_(False)]
                        if statistic not in ["s1","s5","s4","s8"]:
                            if timescale == "annual":
                                title = " for year " + year
                                if year != "":
                                    holder_df = get_yearcounts(barangay_df, intruder_df, province=province, municipality=municipality, barangay=barangay, year=year)
                                else:
                                    error_message = "No year selected"
                            else:
                                if month != "":
                                    title = " for " + monthnames[int(month)] + " " + year
                                    if statistic != "s1" or statistic != "s5" :
                                        holder_df = get_monthcounts(barangay_df, intruder_df, province=province, municipality=municipality, barangay=barangay, year=year, month=month)
                                    # else:
                                    #     holder_df = get_monthrecord(intruder_df, province=province, municipality=municipality, barangay=barangay, year=year, month=month)
                                else:
                                    error_message = "No month selected"
                        if error_message == None:
                            if statistic != "":
                                if statistic == "s1" or statistic == "s5": # specific barangay buoy
                                    if buoynum != "":
                                        x = None
                                        bn = np.int64(int(buoynum[1:]) * 1.0)
                                        intruder_df = intruder_df.query('buoy_number == @bn')
                                        if month != "":
                                            xlabel = 'Day'
                                            holder_df= get_dailycounts(intruder_df,year,month)
                                            x = holder_df['Day']
                                        else:
                                            holder_df = get_monthrangecounts(barangay_df, intruder_df,province=province, municipality=municipality, barangay=barangay, year=year,month_from=1,month_to=12)
                                            holder_df = pd.DataFrame({'count':holder_df.loc[int(buoynum[1:])]})
                                            x = holder_df.index
                                            xlabel = 'Month'

                                        title = "Barangay " + barangay + "s' Buoy Number " + buoynum[1:] + " " + recogtext + " Frequency " + title
                                        if not holder_df.empty:
                                            graph = get_performance_plot("bar plot", x=x, y=holder_df['count'], data=holder_df, title = title, xlabel=xlabel)
                                        else:
                                            error_message = "No records exist"
                                    else:
                                        error_message = "No buoy_number selected"
                                elif statistic == "s2" or statistic == "s6": # each barangay buoy, bar
                                    title = "Barangay " + barangay + "s' Buoy " + recogtext + " Frequency " + title
                                    graph = get_performance_plot("bar plot", x=holder_df['buoy_number'], y=holder_df['count'], data=holder_df, title=title, xlabel="Buoy Number")
                                elif statistic == "s3" or statistic == "s7": # each barangay, pie
                                    holder_df = holder_df[holder_df['count'] > 0]
                                    title = "Barangay " + barangay+ "s' Buoy-"+ recogtext + " Ratio " + title
                                    graph = get_performance_plot("pie chart", x=holder_df['buoy_number'], y=holder_df['count'], data=holder_df, title=title)
                                elif statistic == "s4" or statistic == "s8": # heat map, different function
                                    if year_from != "" and year_to != "":
                                        title = "Barangay " + barangay + "s' " + recogtext + " Frequency Heat Map " + title
                                        holder_df = get_yearrangecounts(barangay_df, intruder_df, province=province, municipality=municipality, barangay=barangay, year_from=year_from, year_to=year_to)
                                        if not holder_df.empty:
                                            graph = get_performance_plot("heat map",data=holder_df,title=title, xlabel = "Buoy Number")
                                        else:
                                            error_message = "No records exist"
                                        # graph = yearoverall_heatmap(intruder_df, province=province, municipality=municipality, barangay=barangay, year_from=year_from, year_to=year_to)
                                    else:
                                        error_message = "Incomplete year range"
                            else:
                                error_message = "No statistic selected"
                        else:
                            error_message = "No records exist"
                    else:
                        error_message = "No timescale selected"
                # holder_df = intruder_df[(intruder_df['date'] > date_from) & (intruder_df['date'] <= date_to)]
            else:
                error_message = "Incomplete location input" # null field detected

    else:
        error_message = "No record in the database"


    context = {
        'graph' : graph,
        'error_message' : error_message,
    }

    return render(request, 'product/statistics.html',context)

def plots_view(request):

    barangay_df = pd.DataFrame(BarangayBuoy.objects.all().values())
    error_message = None
    graph = None


    if barangay_df.shape[0] > 0 :
        if request.method == 'POST':
            level = request.POST['level']
            province = request.POST['province']
            municipality = request.POST['municipality']
            barangay = request.POST['barangay']

            print(municipality)
            print(barangay)
            if level != "":
                if level == "provincial" or level == "municipal" or level == "barangay":
                    if province != "":
                        if level == "municipal" or level == "barangay":
                            if municipality != "":
                                if level == "barangay": # barangay level
                                    barangay_buoys = get_brgy_buoyrecord(barangay_df, province=province, municipality=municipality, barangay=barangay)
                                    brgyshp = get_barangayshp(province=province, municipality=municipality, barangay=barangay)
                                    if barangay_buoys.shape[0] > 0 and not barangay_buoys.empty:
                                        # graph here!
                                        graph = get_performance_plot("geoplot", data = barangay_buoys, gdf = brgyshp)
                                        # pass
                                    else:
                                        error_message = "No records exist"
                                else: # municipal level
                                    muni_buoys = get_municipal_buoyrecord(barangay_df, province=province, municipality=municipality)
                                    print("done!")
                                    if muni_buoys.shape[0] > 0 and not muni_buoys.empty:
                                        munishp = get_municipalityshp(province=province, municipality=municipality)
                                        graph = get_performance_plot("geoplot", data = muni_buoys, gdf = munishp)
                                        # graph here
                                    else:
                                        error_message = "No records exist"
                            else:
                                error_message = "No municipality selected" # null municipality
                        else: # provincial level
                            prov_buoys = get_provincial_buoyrecord(barangay_df, province=province)
                            if prov_buoys.shape[0] > 0 and not prov_buoys.empty:
                                prov_shp = get_provinceshp(province=province)
                                # graph here
                                graph = get_performance_plot("geoplot", data = prov_buoys, gdf = prov_shp)
                                pass
                            else:
                                error_message = "No records exist"
                    else:
                        error_message = "No province selected" # null province
                else:
                    if not barangay_df.empty:
                        barangay_df['Coordinates'] = barangay_df.apply(lambda x: 'Point(' + str(x['longitude']) +" "+ str(x['latitude']) +')', axis=1).apply(wkt.loads)
                        national_shp = get_nationalshp()
                        # graph here
                        graph = get_performance_plot("geoplot", data = barangay_df, gdf = national_shp)
                    else:
                        error_message = "No records exist"
            else:
                error_message = "No level selected" # null level
    else:
        error_message = "Barangay Database Empty "

    #what you want to display, used in main html
    context = {
        'graph' : graph,
        'error_message' : error_message,
    }

    return render(request, 'product/plots.html',context)
