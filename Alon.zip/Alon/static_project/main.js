// javascript functionality for all that use static

$( document ).ready(function() {
  $('.ui.dropdown')
    .dropdown()
  ;
});
